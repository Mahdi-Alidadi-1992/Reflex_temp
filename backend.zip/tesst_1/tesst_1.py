"""Welcome to Reflex! This file outlines the steps to create a basic app."""

from pydantic import BaseModel
import reflex as rx
from rxconfig import config
from typing import Optional
from Pages import Heading

class User(BaseModel):
    name: str
    linkedin_page: str

class UserState(rx.State):
    """The app state."""
    users: list[User] = []
    name: str = ""
    linkedin_page: str = ""

    def add_user(self, form_data: Optional[dict] = None):
        """Add a new user to the list."""
        if form_data:
            self.name = form_data["name"]
            self.linkedin_page = form_data["linkedin_page"]
        # Validate and add user
        if not self.name or not self.linkedin_page:
            return
        if not self.linkedin_page.startswith("https://"):
            self.linkedin_page = "https://" + self.linkedin_page
        # Check if the user already exists
        for user in self.users:
            if user.name == self.name and user.linkedin_page == self.linkedin_page:
                return
        # If the user does not exist, add it
        self.name = self.name.strip()
        self.linkedin_page = self.linkedin_page.strip()
        # Ensure the name and LinkedIn page are not empty
        self.users.append(User(name=self.name, linkedin_page=self.linkedin_page))

    
    def remove_user(self, index: int):
        self.users.pop(index)
        
    def get_users(self):
        return self.users

    def set_linkedin_page(self, linkedin_page: str):
        if linkedin_page.startswith("https://"):
            self.linkedin_page = linkedin_page
        else:
            self.linkedin_page = "https://" + linkedin_page


def form() -> rx.Component:
    # Form to add a new user
    return rx.form(
        rx.flex(
        rx.input(
            placeholder="Enter Name",
            name="name",
            required=True,
            style={"margin-bottom": "10px"}
        ),
        rx.input(
            placeholder="Enter LinkedIn Page",
            name="linkedin_page",
            required=True,
            style={"margin-bottom": "10px"}
        ),
        rx.button("Add User",name= "Add", type="submit"),
        direction="column",
        spacing="4",
    ),
        on_submit=UserState.add_user,
        style={"margin-bottom": "20px"}
    )

def dialog_form() -> rx.Component:
    # Dialog form to add a new user
    return rx.dialog.root(
        rx.dialog.trigger(
            rx.button("+ Add User"),
            style={"margin-bottom": "20px"}
        ),
        rx.dialog.content(
            rx.dialog.title("Add New User"),
            rx.dialog.description(
                form()
            ),
            rx.dialog.close(
                rx.button("Close Dialog", size="3"),
            )
        ),
        style={"max-width": "400px", "margin": "auto"}
    )
    
def display_users() -> rx.Component:
    return rx.table.root(
            rx.table.header(
                rx.table.row(
                    rx.table.cell("Name", style={"text-align": "center", "font-weight": "bold", "border": "1px solid #ddd"}),
                    rx.table.cell("LinkedIn Page", style={"text-align": "center", "font-weight": "bold", "border": "1px solid #ddd"}),
                    rx.table.cell("Action", style={"text-align": "center", "font-weight": "bold", "border": "1px solid #ddd"}),
                )
            ),
            rx.table.body(
                rx.foreach(UserState.users, lambda user, index: rx.table.row(
                    rx.table.cell(user.name, style={"text-align": "center", "border": "1px solid #ddd"}),
                    rx.table.cell(rx.link(rx.button(user.linkedin_page), href=user.linkedin_page, target="_blank")),
                    rx.table.cell(
                        rx.button("Remove", on_click=lambda: UserState.remove_user(index)),
                        style={"text-align": "center", "border": "1px solid #ddd"}
                    ),
                    
                ))
            ),

        )
def index() -> rx.Component:
    # Welcome Page (Index)
    return rx.vstack(
        Heading.header_section(),
        rx.text("Salam"),
        rx.text("make sure"),
        
    )
     

app = rx.App()
app.add_page(index, image = "/Page_icon.png", title="Welcome Page")
