from pathlib import Path

# Define the base path for the Pages module
BASE_PATH = Path(__file__).parent