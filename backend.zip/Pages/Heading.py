import reflex as rx
from rxconfig import config

def header_section() -> rx.Component:    
    return rx.box(
        # Background image box
        rx.box(
            # Overlay
            rx.text(
                "Welcome to Lunch Hero!",
                font_size="3xl",
                font_weight="bold",
                color=rx.color("black",7),
                text_align="center",
                z_index=1,
                position="relative"
            ),
            height="300px",
            width="100%",
            background_image="url('../Header_image_2.png')",
            background_size="cover",
            background_position="center",
            display="flex",
            align_items="center",
            justify_content="center",
        )
    )