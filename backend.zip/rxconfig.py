import reflex as rx

config = rx.Config(
    app_name="tesst_1",
    plugins=[rx.plugins.TailwindV3Plugin()],
)